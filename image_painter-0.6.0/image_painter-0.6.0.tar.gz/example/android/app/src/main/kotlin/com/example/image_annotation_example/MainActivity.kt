package com.example.image_painter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
