class TextDelegate {
  final String noneZoom = "None / Zoom";
  final String line = "Line";
  final String rectangle = "Rectangle";
  final String drawing = "Drawing";
  final String circle = "Circle";
  final String arrow = "Arrow";
  final String dashLine = "Dash line";
  final String text = "Text";
  final String changeMode = "Change Mode";
  final String changeColor = "Change Color";
  final String changeBrushSize = "Change Brush Size";
  final String undo = "Undo";
  final String done = "Done";
  final String clearAllProgress = "Clear All Progress";
}
